
document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to the blog! Customize this script as needed.');
});
